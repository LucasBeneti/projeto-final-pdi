import numpy
import cv2 as cv

img = cv.imread("./mini_puppy.png");

cv.imshow('teste',img);
cv.waitKey(0)

# instalar com -r <nome da file>